#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

chcon u:object_r:system_file:s0 $MODDIR/common/product/etc/embedded_rules_list.xml

# Remove Files
rm /data/system/users/0/magic_window_setting_config.xml
rm /data/system/magicWindowFeature_magic_window_application_list.xml

# Move Back Files
chmod 666 /product/etc/embedded_rules_list.xml
chown root:root /product/etc/embedded_rules_list.xml
chmod 666 /data/system/cloudFeature_embedded_rules_list.xml
chown root:root /data/system/cloudFeature_embedded_rules_list.xml

rm /product/etc/embedded_rules_list.xml
cp $MODDIR/common/product/etc/embedded_rules_list_bak /product/etc/embedded_rules_list.xml
rm /data/system/cloudFeature_embedded_rules_list.xml
cp $MODDIR/common/product/etc/embedded_rules_list_bak /data/system/cloudFeature_embedded_rules_list.xml
rm /data/system/users/0/embedded_setting_config.xml

# Disable Cloud Feature
# chmod 440 /product/etc/embedded_rules_list.xml
# chown system /product/etc/embedded_rules_list.xml
# chmod 440 /data/system/cloudFeature_embedded_rules_list.xml
# chown system /data/system/cloudFeature_embedded_rules_list.xml
# chmod 440 /data/system/users/0/embedded_setting_config.xml
# chown system /data/system/users/0/embedded_setting_config.xml

# 这个脚本将以 post-fs-data 模式执行
# 更多信息请访问 Magisk 主题
